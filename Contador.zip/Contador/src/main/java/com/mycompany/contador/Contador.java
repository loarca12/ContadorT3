/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.contador;


public class Contador {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
