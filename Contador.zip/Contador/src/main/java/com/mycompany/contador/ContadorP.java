
package com.mycompany.contador;


public class ContadorP extends javax.swing.JFrame {

  private boolean isRunning = false; // variable para controlar el estado del contador
    private int segundos = 0; // variable para almacenar el tiempo transcurrido en segundos
    private Thread hilo; // variable para almacenar el hilo del contador
    
    public ContadorP() {
        initComponents();
    }


    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        lbl_contador = new javax.swing.JLabel();
        btn_contador = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabel1.setText("CONTADOR EN MINUTOS Y SEGUNDOS.");

        lbl_contador.setText("0:0");

        btn_contador.setText("Iniciar/Parar");
        btn_contador.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_contadorActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(43, 43, 43)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel1)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(43, 43, 43)
                        .addComponent(btn_contador)))
                .addContainerGap(26, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(lbl_contador, javax.swing.GroupLayout.PREFERRED_SIZE, 47, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(115, 115, 115))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1)
                .addGap(34, 34, 34)
                .addComponent(lbl_contador)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btn_contador)
                .addContainerGap(15, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btn_contadorActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_contadorActionPerformed
        // TODO add your handling code here:
        if (!isRunning) { // si el contador no está corriendo, se inicia
            isRunning = true;
            hilo = new Thread(new Runnable() {
                public void run() {
                    while (isRunning) {
                        segundos++;
                        int minutos = segundos / 60;
                        int seg = segundos % 60;
                        lbl_contador.setText(minutos + ":" + seg);
                        try {
                            Thread.sleep(1000);
                        } catch (InterruptedException ex) {
                            System.out.println("Error: " + ex.getMessage());
                        }
                    }
                }
            });
            hilo.start();
        } else { // si el contador está corriendo, se detiene
            isRunning = false;
            hilo.interrupt();
        }
    }//GEN-LAST:event_btn_contadorActionPerformed

    
    public static void main(String args[]) {
        
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new ContadorP().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btn_contador;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel lbl_contador;
    // End of variables declaration//GEN-END:variables
}
